#include<stdio.h>
int main(){
int length,width,result;
printf("enter the length:");
scanf("%d",&length);
printf("enter the width :");
scanf("%d",&width);
result=length*width;
printf("The area of rectangle is :%d ",result);
return 0;


}