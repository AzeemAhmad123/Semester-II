#include<stdio.h>
int main(){
printf("twinkle twinkle little star,\n\tHow i wounder what are !\n\t\tUp sbove the world so high\n\t\tlike a diamond in the sky.\nTwinklw ,twinkole ,little star,\n\t how i wounder what you are !");



}