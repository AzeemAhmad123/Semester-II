#include<stdio.h>
int main(){
int kilogram,meter,result;
printf("enter the kilogram :");
scanf("%d",&kilogram);
printf("enter the mass :");
scanf("%d",&meter);
result=kilogram/meter*meter;
printf("The result is : %d",result);





}