#include<stdio.h>
int main(){
int hours,seconds,minutes;
printf("enter the hour:");
scanf("%d",&hours);
seconds=hours*3600;
minutes=hours*60;
printf("The result is : %d\n",seconds);
printf("The result is : %d\n",minutes);
}